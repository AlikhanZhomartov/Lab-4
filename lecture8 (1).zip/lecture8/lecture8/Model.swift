//
//  Model.swift
//  lecture8
//
//  Created by admin on 08.02.2021.
//

import Foundation


public struct Model: Codable{
    let weather: [Weather]?
    let main: MainRes?
    let name: String?
}

struct MainRes: Codable {
    let temp: Double?
    let feels_like: Double?
}

struct Weather: Codable {
    let main: String?
    let description: String?
}




public struct ModelForecastOneWeek: Codable{
    let daily: [Daily]?
}

struct Daily: Codable{
    let temp: Temp?
    let feelsLike: FeelsLike?
    let weather: [WeatherElement]?
    let dt: Int?
    
    enum CodingKeys: String, CodingKey {
           case dt
           case temp
           case feelsLike = "feels_like"
           case weather
    }
}

struct Temp: Codable{
    let day, min, max, night: Double?
    let eve, morn: Double?
}

struct FeelsLike: Codable{
    let day, night, eve, morn: Double?
}

struct WeatherElement: Codable{
    let main, weatherDescription: String?
    
    enum CodingKeys: String, CodingKey {
          case main
          case weatherDescription = "description"
      }
}
