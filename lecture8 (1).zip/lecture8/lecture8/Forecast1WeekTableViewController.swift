//
//  Forecast1WeekTableViewController.swift
//  lecture8
//
//  Created by Костицина Елизавета Константиновна on 20.02.2021.
//

import UIKit
import Alamofire

class Forecast1WeekTableViewController: UITableViewController, UIPickerViewDelegate {
    
    var formattedDates : [String] = []
    var temps: [String] = []
    var feelsLike: [String] = []
    var descriptionWeather: [String] = []
    var city = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData(city: self.city)
    }
    
    
    func fetchData(city: String){
        var lat:String = ""
        var lon: String = ""
        switch city{
        case "Nur-Sultan": lat = Constants.NurSultan.lat; lon = Constants.NurSultan.lon
        case "Berlin": lat = Constants.Berlin.lat; lon = Constants.Berlin.lon
        case "London": lat = Constants.London.lat; lon = Constants.London.lon
        default: print("")
        }
        AF.request("https://api.openweathermap.org/data/2.5/onecall?lat=\(lat)&lon=\(lon)&exclude=hourly&appid=\(Constants.apiKey)&&units=metric").responseJSON { response in
            guard let objects = response.data else {return}
                do {
                    let json = try JSONDecoder().decode(ModelForecastOneWeek.self, from: objects)
                    guard let infoFromServer = json.daily else {return}
                    self.formateData(arrayOfUnixDates: infoFromServer)
                    for info in infoFromServer{
                        self.temps.append(String((info.temp?.day)?.rounded() ?? 0) + " C°")
                        self.feelsLike.append(String((info.feelsLike?.day)?.rounded() ?? 0) + " C°" )
                        self.descriptionWeather.append(info.weather?.first?.weatherDescription ?? "0")
                    }
                    self.tableView.reloadData()
                    
                } catch let error as NSError {
                    print(error)
                }
        }
    }
    
    func formateData(arrayOfUnixDates: [Daily]){
        for i in arrayOfUnixDates{
            guard let dateUnix = i.dt else {return}
            let date = Date(timeIntervalSince1970: Double(dateUnix))
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .medium
            let localDate = dateFormatter.string(from: date)
            formattedDates.append(localDate)
        }
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return formattedDates.isEmpty ? 0 : formattedDates.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ForecastCell", for: indexPath) as! Forecast1WeekTableViewCell
        DispatchQueue.main.async{
    
            cell.dateLabel.text = self.formattedDates[indexPath.row]
            cell.descriptionWeather.text = self.descriptionWeather[indexPath.row]
            cell.feelsLike.text = self.feelsLike[indexPath.row]
            cell.tempLabel.text = self.temps[indexPath.row]
        }
        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        150
    }
    

}

class Forecast1WeekTableViewCell: UITableViewCell{
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var descriptionWeather: UILabel!
    @IBOutlet weak var feelsLike: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
}
