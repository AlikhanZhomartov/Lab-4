//
//  Constants.swift
//  lecture8
//
//  Created by admin on 09.02.2021.
//

import Foundation

struct Constants {
    static let host = "https://api.openweathermap.org/data/2.5/weather"
    static let city = "Astana"
    static let apiKey = ""
    static let NurSultan = (lon: "71.446", lat: "51.1801")
    static let Berlin = (lon: "13.4105", lat: "52.5244")
    static let London = (lon: "-0.1257", lat: "51.5085")
}


