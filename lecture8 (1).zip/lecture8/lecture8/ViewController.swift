//
//  ViewController.swift
//  lecture8
//
//  Created by admin on 08.02.2021.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var chooseCityPickerView: UIPickerView!
    @IBOutlet weak var cityName: UILabel!
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var feelsLikeTemp: UILabel!
    @IBOutlet weak var desc: UILabel!
    
    let cities = ["Nur-Sultan","Berlin","London"]
    var city :String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        city = cities[0]
        fetchData(city:cities[0])
        chooseCityPickerView.dataSource = self
        chooseCityPickerView.delegate = self
    }
    
    
    var myData: Model?
    
    
    private var decoder: JSONDecoder = JSONDecoder()
    
    
    func updateUI(){
        cityName.text = myData?.name
        temp.text = "\(String((myData?.main?.temp)?.rounded() ?? 0.0)) °C"
        feelsLikeTemp.text = "\(String((myData?.main?.feels_like)?.rounded() ?? 0.0)) °C"
        desc.text = myData?.weather?.first?.description
    }
    
    func fetchData(city: String){
        let url  = Constants.host + "?q=\(city)&appid=\(Constants.apiKey)&units=metric"
        AF.request(url).responseJSON { (response) in
            switch response.result{
            case .success(_):
                guard let data = response.data else { return }
                do{
                    let answer = try? self.decoder.decode(Model.self, from: data)
                    self.myData = answer
                    self.updateUI()
                }catch{
                    print("Parsing error")
                }
            case .failure(let err):
                print(err.errorDescription ?? "")
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let forecastVC = segue.destination as? Forecast1WeekTableViewController else {return}
        guard segue.identifier == "ShowForecast" else {return}
        forecastVC.city = self.city
    }
}


extension ViewController: UIPickerViewDataSource, UIPickerViewDelegate{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        let city = cities[row]
        fetchData(city: city)
        self.city = city
    }
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        let cell = cities[row]
        let attrString = NSAttributedString(string: cell, attributes: [.foregroundColor : UIColor.white])
        return attrString
    }
    
}



